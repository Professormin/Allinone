import {Config} from '@remotion/cli/config';
Config.setOverwriteOutput(true);
Config.setConcurrency(2);
